# Forge IDE

**AI-Powered Code Editor — No API Key Needed**

Forge IDE drives DeepSeek or Gemini through browser
automation to code, test, and ship software — completely free.

---

## Why Forge IDE?

- **Free** — No API key. Uses DeepSeek or Gemini's free web UI.
- **Autonomous** — Reads files, writes code, runs tests. Loops until done.
- **Cross-platform** — Linux, macOS, Windows.
- **Built-in IDE** — Full code editor with terminal, file explorer, and AI chat.

---

## Installation

```bash
npm install -g forge-ide
```

Or use the Windows installer from the `installer/` folder.

---

## Quick Start

```bash
# Launch the IDE
forge-ide

# Run a task from command line
forge-agent "build a REST API with Express and JWT auth"

# Interactive mode
forge-agent --interactive
```

---

## Features

| Feature | Description |
|---|---|
| Browser Automation | Drives DeepSeek, Gemini — no API key |
| 37+ Built-in Tools | File I/O, git, shell, search, tests, packages |
| Persistent Memory | Remembers project tech stack and past tasks |
| Agent Profiles | default, backend, frontend, data-science, devops |
| Task Templates | 10 built-in templates |
| Session Resume | Continue tasks that stopped halfway |
| Watch Mode | Auto re-run on file changes |
| Custom Plugins | Drop a .js file to add any tool |
| Security Sandbox | Blocks SSH keys, credentials, path traversal |

---

## Built-in Tools (37+)

**File:** read_file, write_file, append_to_file, replace_in_file, delete_file, move_file, copy_file, create_directory, list_directory, get_file_info, write_files

**Search:** search_in_files, search_codebase, find_files

**Shell:** run_command, start_process, stop_process, list_processes, read_process_logs

**Git:** git_status, git_log, git_diff, git_branches, git_show, git_blame

**Dev:** run_tests, install_package, diff_files, patch_file

**Env:** read_env, set_env_var, delete_env_var, list_env_files, check_env_vars

**System:** take_screenshot, read_clipboard, write_clipboard

---

## Agent Profiles

```bash
forge-agent --profile=backend      # Node.js, Python, Go, REST APIs
forge-agent --profile=frontend     # React, Vue, HTML/CSS
forge-agent --profile=data-science # Python, pandas, ML
forge-agent --profile=devops       # Docker, CI/CD, shell scripts
```

---

## Task Templates

```bash
forge-agent --template=add-typescript    # Add TypeScript to any JS project
forge-agent --template=add-jest          # Set up Jest testing
forge-agent --template=add-docker        # Dockerfile + docker-compose
forge-agent --template=add-github-actions # CI/CD pipeline
forge-agent --template=fix-tests         # Run and fix all failing tests
forge-agent --template=code-review       # Comprehensive code review
forge-agent --list-templates             # See all 10 templates
```

---

## Session Resume

```bash
forge-agent --history         # Browse past tasks
forge-agent --resume          # Pick and resume a past task
forge-agent --resume=last     # Resume most recent task immediately
forge-agent --rerun           # Re-run most recent task fresh
```

---

## CLI Reference (key flags)

```
forge-agent [OPTIONS] [TASK]

Core:      --interactive -i  --dir  --model  --profile  --plan  --think
Sessions:  --resume  --rerun  --history  --no-memory
Templates: --template  --list-templates  --save-template
Output:    --format  --output  --no-tui  --compact
Watch:     --watch  --watch-pattern  --watch-debounce
Performance: --max-iterations  --timeout  --no-timeout
Plugins:   --list-plugins  --new-plugin
Config:    --setup  --config-path
Debug:     --debug  --headless  --diagnostics  --security
Help:      --help  --help=<topic>  --cheatsheet  --man
```

---

## Configuration

```json
// ~/.forge-ide/config.json
{
  "MODEL": "deepseek",
  "MAX_ITERATIONS": 100,
  "RESPONSE_TIMEOUT": 600000,
  "ACTIVE_PROFILE": "default",
  "MEMORY_ENABLED": true,
  "CACHE_ENABLED": true
}
```

Run `forge-agent --setup` for guided configuration.

---

## License

MIT — see [LICENSE](LICENSE)
